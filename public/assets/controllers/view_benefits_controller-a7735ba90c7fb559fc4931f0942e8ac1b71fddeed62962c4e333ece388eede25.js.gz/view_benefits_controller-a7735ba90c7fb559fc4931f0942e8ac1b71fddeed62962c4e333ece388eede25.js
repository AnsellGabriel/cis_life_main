import { Controller } from "@hotwired/stimulus"

// Connects to data-controller="view-benefits"
export default class extends Controller {
  connect() {
  }
};
